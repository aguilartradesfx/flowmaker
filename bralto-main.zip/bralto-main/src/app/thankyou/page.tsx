import ThankYouPage from "@/components/thank-you/ThankYouPage";

export default function ThankYouPageRoute() {
  return <ThankYouPage />;
}
