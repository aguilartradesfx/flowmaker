'use client';

export function VoiceWidget() {
  // Widget disabled temporarily for performance optimization
  return null;
}
